from gensim.models import Word2Vec
import numpy as np
MAX_LEN = 512
EMBED_DIM = 128  # Word2Vec embedding size

import os
import numpy as np

SEED = 42
def balance_data(x1, x2, y):
    pos_idx = np.where(y[:, 0] == 1)[0]
    neg_idx = np.where(y[:, 0] == 0)[0]
    n_pos, n_neg = len(pos_idx), len(neg_idx)
    if n_pos == n_neg: return x1, x2, y
    if n_pos < n_neg:
        repeat_idx = np.random.choice(pos_idx, n_neg - n_pos, replace=True)
    else:
        repeat_idx = np.random.choice(neg_idx, n_pos - n_neg, replace=True)
    x1_bal = np.concatenate([x1, x1[repeat_idx]], axis=0)
    x2_bal = np.concatenate([x2, x2[repeat_idx]], axis=0)
    y_bal = np.concatenate([y, y[repeat_idx]], axis=0)
    perm = np.random.permutation(len(x1_bal))
    return x1_bal[perm], x2_bal[perm], y_bal[perm]
def load_data(file_path):
    texts, labels = [], []
    with open(file_path, 'r', encoding='utf-8') as f:
        current_text = []
        for line in f:
            line = line.strip()
            if line == '---------------------------------':
                if current_text:
                    label = int(current_text[-1])
                    text = current_text[:-1]
                    texts.append(text)
                    labels.append(label)
                    current_text = []
            else:
                current_text.append(line)
        if current_text:
            label = int(current_text[-1])
            text = current_text[:-1]
            texts.append(text)
            labels.append(label)
    return texts, np.array(labels).reshape(-1, 1)

def train_word2vec(texts):
    model = Word2Vec(sentences=texts, vector_size=EMBED_DIM, window=5, min_count=1, workers=4, seed=SEED)
    return model

def texts_to_vectors(texts, w2v_model):
    vectors = []
    for tokens in texts:
        vec = []
        for token in tokens:
            if token in w2v_model.wv:
                vec.append(w2v_model.wv[token])
            else:
                vec.append(np.zeros(EMBED_DIM))
        if len(vec) < MAX_LEN:
            vec += [np.zeros(EMBED_DIM)] * (MAX_LEN - len(vec))
        else:
            vec = vec[:MAX_LEN]
        vectors.append(vec)
    return np.array(vectors, dtype=np.float32)

