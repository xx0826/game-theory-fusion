import argparse


def parse_args():
    parser = argparse.ArgumentParser()
    # Training parameters
    parser.add_argument("--batch_size", type=int, default=32,)
    parser.add_argument("--lr", type=float, default=0.002)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--dropout", type=float, default=0.5)
    parser.add_argument("--model_path", type=str, default="./models/", help="model save path")
    parser.add_argument("--log_path", type=str, default="./logs/", help="log save path")
    parser.add_argument('-D', '--dataset', type=str, default='dataset/reentrancy',
                        choices=['dataset/IntegerOverOrUnderFlow', 'dataset/reentrancy', 'dataset/Selfdestruct', 'dataset/timestamp', 'dataset/txOrigin'],
                        help="training dataset")
    # Model-specific parameters
    parser.add_argument("--max_len", type=int, default=512, help="max sequence length")
    parser.add_argument("--embed_dim", type=int, default=128, help="embedding dimension")
    return parser.parse_args()

