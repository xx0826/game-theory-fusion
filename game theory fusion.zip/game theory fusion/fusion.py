from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Dropout, LSTM, LeakyReLU, Bidirectional, Input, LayerNormalization, Lambda
from tensorflow.keras.optimizers import Adamax
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Layer
import tensorflow as tf
from keras.models import Model
from keras.layers import Dense, Dropout, LSTM, LeakyReLU, Bidirectional, Input, LayerNormalization, Add, Conv1D, GlobalMaxPooling1D, Concatenate
from keras.optimizers import Adamax
from parser1 import parse_args
from tensorflow.keras import regularizers
args = parse_args()
class GameTheoryFusion(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs):
        # inputs: list of [batch, seq_len, hidden]
        feas = tf.stack(inputs, axis=0)


        numerator = tf.reduce_sum(feas * feas, axis=-1, keepdims=True)  # (num_modalities, batch, seq_len, 1)
        denominator = tf.sqrt(tf.reduce_sum(tf.square(numerator), axis=0, keepdims=True) + 1e-8)  # (1, batch, seq_len, 1)
        a = numerator / (denominator + 1e-8)  # (num_modalities, batch, seq_len, 1)

        # (num_modalities, batch, 1, 1)
        a_sum = tf.reduce_sum(a, axis=2, keepdims=True)
        a_models = a_sum / (tf.reduce_sum(a_sum, axis=0, keepdims=True) + 1e-8)

        # Weight multiplied by features
        wei_feas = a_models * feas  # (num_modalities, batch, seq_len, hidden)

        # fuse modalities -> (batch, seq_len, hidden)
        result = tf.reduce_sum(wei_feas, axis=0)
        return result

class MultiHeadCrossAttention(Layer):
    def __init__(self, num_heads=2, dropout_rate=0.1, **kwargs):
        super().__init__(**kwargs)
        self.num_heads = num_heads
        self.dropout_rate = dropout_rate
        self.layernorm = LayerNormalization()

    def build(self, input_shape):
        hidden_size = input_shape[0][-1]
        self.Wq = self.add_weight(shape=(hidden_size, hidden_size),
                                  initializer='glorot_uniform', name='Wq')
        self.Wk = self.add_weight(shape=(hidden_size, hidden_size),
                                  initializer='glorot_uniform', name='Wk')
        self.Wv = self.add_weight(shape=(hidden_size, hidden_size),
                                  initializer='glorot_uniform', name='Wv')
        self.Wo = self.add_weight(shape=(hidden_size, hidden_size),
                                  initializer='glorot_uniform', name='Wo')
        super().build(input_shape)

    def split_heads(self, x):
        batch = tf.shape(x)[0]
        seq_len = tf.shape(x)[1]
        hidden = tf.shape(x)[2]
        x = tf.reshape(x, (batch, seq_len, self.num_heads, hidden // self.num_heads))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def combine_heads(self, x):
        x = tf.transpose(x, perm=[0, 2, 1, 3])
        batch = tf.shape(x)[0]
        seq_len = tf.shape(x)[1]
        heads = tf.shape(x)[2]
        dim = tf.shape(x)[3]
        return tf.reshape(x, (batch, seq_len, heads * dim))

    def call(self, inputs, training=None):
        x1, x2 = inputs
        Q = tf.matmul(x1, self.Wq)
        K_mat = tf.matmul(x2, self.Wk)
        V = tf.matmul(x2, self.Wv)

        Qh, Kh, Vh = self.split_heads(Q), self.split_heads(K_mat), self.split_heads(V)
        attn_scores = tf.matmul(Qh, Kh, transpose_b=True) / tf.math.sqrt(tf.cast(tf.shape(Qh)[-1], tf.float32))
        attn_weights = tf.nn.softmax(attn_scores, axis=-1)
        attn_weights = tf.nn.dropout(attn_weights, rate=self.dropout_rate) if training else attn_weights
        attn_out = tf.matmul(attn_weights, Vh)
        attn_out = self.combine_heads(attn_out)
        attn_out = tf.matmul(attn_out, self.Wo)
        return self.layernorm(attn_out + x1)



def dot_product(x, kernel):
    return K.squeeze(K.dot(x, K.expand_dims(kernel)), axis=-1)

class AttentionWithContext(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.supports_masking = True
        self.init = tf.keras.initializers.glorot_uniform()

    def build(self, input_shape):
        self.W = self.add_weight(shape=(input_shape[-1], input_shape[-1]),
                                 initializer=self.init, name='W')
        self.u = self.add_weight(shape=(input_shape[-1],),
                                 initializer=self.init, name='u')
        self.b = self.add_weight(shape=(input_shape[-1],),
                                 initializer='zeros', name='b')
        super().build(input_shape)

    def call(self, x, mask=None):
        # x: [batch, seq_len, hidden_dim]
        uit = K.tanh(K.dot(x, self.W) + self.b)       # [batch, seq_len, hidden_dim]
        ait = K.dot(uit, K.expand_dims(self.u))       # [batch, seq_len, 1]
        ait = K.squeeze(ait, -1)                      # [batch, seq_len]
        a = K.exp(ait)

        if mask is not None:
            a *= K.cast(mask, K.floatx())

        a /= K.cast(K.sum(a, axis=1, keepdims=True) + K.epsilon(), K.floatx())  # 归一化
        a = K.expand_dims(a)                          # [batch, seq_len, 1]

        weighted_input = x * a                        # [batch, seq_len, hidden_dim]
        return K.sum(weighted_input, axis=1)          # [batch, hidden_dim]

# ===========================
# TextCNN Block for AST
# ===========================
def TextCNN_Block(input_tensor, filter_sizes=[3,4,5], num_filters=128, dropout_rate=0.3):
    convs = []
    for fsz in filter_sizes:
        conv = Conv1D(filters=num_filters, kernel_size=fsz, activation='relu', padding='same')(input_tensor)
        pooled = GlobalMaxPooling1D()(conv)
        convs.append(pooled)
    x = Concatenate()(convs)
    x = Dropout(dropout_rate)(x)
    return x

def build_fusion(input_shape):
    input_ast = Input(shape=input_shape)
    input_code = Input(shape=input_shape)

    # TextCNN for AST
    textcnn_ast = TextCNN_Block(input_ast, filter_sizes=[3,4,5], num_filters=128, dropout_rate=0.3)
    ast_expanded = tf.expand_dims(textcnn_ast, axis=1)

    # BiLSTM for Code
    lstm_code = Bidirectional(LSTM(64, return_sequences=True, dropout=0.3, recurrent_dropout=0.3,
                                   kernel_regularizer=regularizers.l2(1e-4)))(input_code)
    same_dim = 256
    ast_seq = Dense(same_dim)(tf.repeat(ast_expanded, repeats=tf.shape(lstm_code)[1], axis=1))
    code_seq = Dense(same_dim)(lstm_code)

    # Cross Attention
    cross_attn_ast = MultiHeadCrossAttention(num_heads=4)([ast_seq, code_seq])
    cross_attn_code = MultiHeadCrossAttention(num_heads=4)([code_seq, ast_seq])

    # Game Theory fusion
    fused = GameTheoryFusion()([cross_attn_ast, cross_attn_code])
    fused = GlobalMaxPooling1D()(fused)

    x = Dense(128, kernel_regularizer=regularizers.l2(1e-4))(fused)
    x = LeakyReLU()(x)
    x = Dropout(0.5)(x)
    x = Dense(64, kernel_regularizer=regularizers.l2(1e-4))(x)
    x = LeakyReLU()(x)
    x = Dropout(0.5)(x)
    output = Dense(1, activation='sigmoid')(x)

    model = Model(inputs=[input_ast, input_code], outputs=output)
    model.compile(optimizer=Adamax(0.0005),
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    return model