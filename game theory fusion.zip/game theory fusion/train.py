import random
import numpy as np
from keras.models import Model
from keras.layers import Dense, Dropout, LSTM, LeakyReLU, Bidirectional, Input, LayerNormalization, Add
from keras.optimizers import Adamax
from sklearn.model_selection import train_test_split
from keras import backend as K
from keras.layers import Layer
import matplotlib.pyplot as plt
from keras.callbacks import ReduceLROnPlateau, EarlyStopping, CSVLogger
import tensorflow as tf
import argparse
from gensim.models import Word2Vec
from keras import regularizers
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
import os
import tensorflow as tf
from tensorflow.keras.layers import Layer
from load import load_data, train_word2vec, texts_to_vectors, balance_data
from parser1 import parse_args
from fusion import build_fusion
SEED = 42
os.environ['PYTHONHASHSEED'] = str(SEED)
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)
args = parse_args()
MAX_LEN = 512
EMBED_DIM = 300

def train_test_model(model, x_train_ast, x_train_code, y_train, x_test_ast, x_test_code, y_test):
    reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=5, min_lr=args.lr)
    history = model.fit(
        [x_train_ast, x_train_code], y_train,
        batch_size=args.batch_size, epochs=args.epochs,
        validation_data=([x_test_ast, x_test_code], y_test),
        callbacks=[reduce_lr]
    )

    values = model.evaluate([x_test_ast, x_test_code], y_test, batch_size=args.batch_size)
    print("Accuracy:", values[1])
    preds = (model.predict([x_test_ast, x_test_code], batch_size=args.batch_size) > 0.5).astype(int)
    y_true = y_test.ravel()
    y_pred = preds.ravel()
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    precision = precision_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    print(f"Precision={precision:.4f} Recall={recall:.4f} F1={f1:.4f}")

    plt.figure(figsize=(10, 5))
    plt.plot(history.history['loss'], 'b--', label='Train Loss')
    plt.plot(history.history['val_loss'], 'b', label='Val Loss')
    plt.plot(history.history['accuracy'], 'r--', label='Train Acc')
    plt.plot(history.history['val_accuracy'], 'r', label='Val Acc')
    plt.xlabel('Epochs'); plt.ylabel('Loss/Acc'); plt.legend(); plt.show()
# ===========================
# main
# ===========================
if __name__ == "__main__":
    ast_texts, ast_labels = load_data('ast.txt')
    code_texts, code_labels = load_data('code_slicing.txt')
    assert np.array_equal(ast_labels, code_labels), "AST and Code tags do not match"
    labels = ast_labels

    w2v_model_ast = train_word2vec(ast_texts)
    w2v_model_code = train_word2vec(code_texts)
    ast_vectors = texts_to_vectors(ast_texts, w2v_model_ast)
    code_vectors = texts_to_vectors(code_texts, w2v_model_code)
    ast_vectors, code_vectors, labels = balance_data(ast_vectors, code_vectors, labels)

    x_train_ast, x_test_ast, y_train, y_test = train_test_split(ast_vectors, labels, test_size=0.2, random_state=SEED)
    x_train_code, x_test_code, _, _ = train_test_split(code_vectors, labels, test_size=0.2, random_state=SEED)

    fusion_model = build_fusion((MAX_LEN, EMBED_DIM))
    fusion_model.summary()
    train_test_model(fusion_model, x_train_ast, x_train_code, y_train, x_test_ast, x_test_code, y_test)